var fs = require('fs');
var readline = require('readline');
var Matrix = require('matrix-slicer');


var matrix = [];
var lineIndex = 0;

// Empty starting object
var Scotia = function(){};

// Helper function for sorting arrays
Scotia.prototype.sortArray = function(a, b) {
    return a - b;
};

// Check if an array can be a valid Sudoku row or column - This function is used by isRowValid() and isColumnValid()
Scotia.prototype.isSudokuArray = function(array) {

    var isSudoku = false;
    var index = 0;
    var arr = Array.from(array);
    arr = arr.sort(this.sortArray);

    for(var i=0; i<9; i++) {
        if(arr[i] === i+1) {
            index++;
        }
    }

    if(index === 9) isSudoku = true;

    return isSudoku;
};

// Check if a row is valid Sudoku row
Scotia.prototype.isRowValid = function(row) {
    return this.isSudokuArray(row)
};

// Check if all rows are valid Sudoku rows
Scotia.prototype.areRowsValid = function(ma) {

    var allRowsValid = false;
    var index = 0;

    for(var i=0; i<9; i++) {
        if(this.isRowValid(ma.getRow(i))){
            index++;
        }
    }

    if(index === 9) {
        allRowsValid = true;
    }

    return allRowsValid;
};

// Check if a column is valid Sudoku column
Scotia.prototype.isColumnValid = function(column) {
    return this.isSudokuArray(column)
};

// Check if all columns are valid Sudoku columns
Scotia.prototype.areColumnsValid = function(ma) {

    var allColumnsValid = false;
    var index = 0;

    for(var i=0; i<9; i++) {
        if(this.isColumnValid(ma.getColumn(i))){
            index++;
        }
    }

    if(index === 9) {
        allColumnsValid = true;
    }

    return allColumnsValid;
};

// Check if all submatrices are valid Sudoku matrices
Scotia.prototype.areSubMatrixValid = function(ma) {

    var allSubMatrixValid = false;
    var index = 0;

    for(var i=0; i<9; i=i+3) {
        for(var j=0; j<9; j=j+3) {

            var subMat = ma.getSubmatrix(i, j, i+3, j+3);
            var mergedArr = [].concat.apply([], subMat);

            if(this.isSudokuArray(mergedArr)) {
                index++;
            }
        }
    }

    if(index === 9) {
        allSubMatrixValid = true;
    }

    return allSubMatrixValid;
};

// Open a Sudoku text file and return a reference to the file
Scotia.prototype.openFile = function(file) {

    this.rl = readline.createInterface({
        input: fs.createReadStream(file)
    });

    return this.rl;
};

// Read line by line asynchronously and populate and a matrix array
Scotia.prototype.readLines = function() {

    this.rl.on('line', (line) => {
        var res = [];
        lineIndex++;

        line.split('').forEach(function (item) {
            res.push(parseInt(item, 10));
        });

        matrix.push(res);
    });

};

// On close event,
// create a matrix using matrix-slicer package
// Throwing exception in case there are not enough lines in the text file
// returning true if matrix is a valid Sudoku
Scotia.prototype.readDone = function() {
    //var self = this;
    this.rl.on('close', () => {
        this.ma = new Matrix(matrix);
        if(lineIndex < 9) {
            throw new Error(9 - lineIndex + ' line missing from ' + process.argv.slice(2).toString());
        }

        return console.log(this.areRowsValid(this.ma) && this.areColumnsValid(this.ma) && this.areSubMatrixValid(this.ma));
    });
};

// Executing the code in this file:
// Open text file
// Read line by line
// On "close" event, return true if valid Sudoku
Scotia.prototype.run = function() {
    this.openFile(process.argv.slice(2).toString());
    this.readLines();
    this.readDone();
};

var scot = new Scotia();
scot.run();

module.exports = Scotia;
