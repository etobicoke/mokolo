var expect = require('chai').expect;
var M = require('matrix-slicer');
var Scotia = require('./scotia');

var scot = new Scotia();
var ma = [[5,3,4,6,7,8,9,1,2],
[6,7,2,1,9,5,3,4,8],
[1,9,8,3,4,2,5,6,7],
[8,5,9,7,6,1,4,2,3],
[4,2,6,8,5,3,7,9,1],
[7,1,3,9,2,4,8,5,6],
[9,6,1,5,3,7,2,8,4],
[2,8,7,4,1,9,6,3,5],
[3,4,5,2,8,6,1,7,9]];

describe('testing Scotia Sudoku', function(){

    before(function () {

    });

    describe('sortArray', function () {
        it('should sort an array of numbers', function () {

            var x = [5, 6, 1, 8, 3, 9, 7, 4, 2];

            var sorted = x.sort(scot.sortArray);

            expect(sorted).to.have.ordered.members([1, 2, 3, 4, 5, 6, 7, 8, 9]);

        });
    });

    describe('isSudokuArray', function() {
        it('should check if a row or column is valid', function() {

            var arr = [4, 9, 1, 3, 5, 7, 8, 2, 6];

            var isSudoku = scot.isSudokuArray(arr);

            expect(isSudoku).to.be.true;

        });
    });

    describe('isRowValid', function() {
        it('should check if a row is valid', function() {

            var arr = [6, 2, 5, 7, 1, 4, 8, 3, 9];

            var isRowValid = scot.isRowValid(arr);

            expect(isRowValid).to.be.true;
        });
    });

    describe('areRowsValid', function() {
        it('should check if all rows are valid', function() {

            var matrix = new M(ma);

            var areRowsValid = scot.areRowsValid(matrix);

            expect(areRowsValid).to.be.true;

        });
    });

    describe('isColumnValid', function() {
        it('should check if a column is valid', function() {

            var arr = [6, 2, 5, 7, 1, 4, 8, 3, 9];

            var isColumnValid = scot.isColumnValid(arr);

            expect(isColumnValid).to.be.true;
        });
    });

    describe('areColumsValid', function() {
       it('should check if all columns are valid', function() {

           var matrix = new M(ma);

           var areColumnsValid = scot.areColumnsValid(matrix);

           expect(areColumnsValid).to.be.true;
       });
    });

    describe('areSubMatrixValid', function() {
        it('should check if all submatrices are valid', function() {

            var matrix = new M(ma);

            var areSubMatrixValid = scot.areSubMatrixValid(matrix);

            expect(areSubMatrixValid).to.be.true;
        });
    });

});


